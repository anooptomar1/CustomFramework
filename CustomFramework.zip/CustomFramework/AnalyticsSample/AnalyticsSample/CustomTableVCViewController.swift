//
//  CustomTableVCViewController.swift
//  AnalyticsSample
//
//  Created by Tomar, Anoop on 11/27/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit
import CommonFramework

class CustomTableVCViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableview: UITableView!
    
    var data = [QuotesModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableview.dataSource = self
        self.tableview.delegate = self
        
        self.tableview.register(ReusableTableCell.self, forCellReuseIdentifier: "cell")
        self.populateModel()
    }
    
    func populateModel() {
        let d1 = QuotesModel(quote: "I work out, I play sports, I go to concerts.", author: "Angie Everhart", image: #imageLiteral(resourceName: "icon_quote"))
        let d2 = QuotesModel(quote: "Right now I'm so old that if I had a big gush of money, I don't know what I'd do with it. I don't travel anymore. I don't need anything, don't want anything. I'd give it to my son, I guess, and let him enjoy it.", author: "Jack Vance", image: #imageLiteral(resourceName: "icon_quote"))
        let d3 = QuotesModel(quote: "The poor don't know that their function in life is to exercise our generosity.", author: "Jean-Paul Sartre", image: #imageLiteral(resourceName: "icon_quote"))
        self.data.append(d1)
        self.data.append(d2)
        self.data.append(d3)
        self.tableview.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell") as! ReusableTableCell
        cell.quoteModel = data[indexPath.row]
        return cell
    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 300
//    }
}

