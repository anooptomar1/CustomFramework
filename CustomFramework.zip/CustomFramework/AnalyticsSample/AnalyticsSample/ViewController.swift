//
//  ViewController.swift
//  AnalyticsSample
//
//  Created by Tomar, Anoop on 7/27/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit
import CommonFramework

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func showDialog(_ sender: RoundButton) {
        let modalView = ModalStatusView(frame: self.view.bounds)
        let pinLarge = #imageLiteral(resourceName: "pin_large")
        modalView.set(image: pinLarge)
        modalView.set(heading: "Apache Airflow")
        modalView.set(subheading: "Data pipeline management workflow system.")
        view.addSubview(modalView)
    }
    
    @IBAction func didTapLaunchVC(_ sender: Any) {
        let customVC = CustomViewController()
        self.present(customVC, animated: true, completion: nil)
    }
    
}

