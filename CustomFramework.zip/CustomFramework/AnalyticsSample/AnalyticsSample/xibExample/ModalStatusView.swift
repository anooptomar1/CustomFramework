//
//  ModalStatusView.swift
//  AnalyticsSample
//
//  Created by Tomar, Anoop on 8/1/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

public class ModalStatusView: UIView {

    @IBOutlet private weak var statusImage: UIImageView!
    @IBOutlet private weak var headingLabel: UILabel!
    @IBOutlet private weak var subheadingLabel: UILabel!
    
    let nibName = "ModalStatusView"
    var contentView: UIView!
    
    var timer: Timer?

    public override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    public func set(image: UIImage) {
        self.statusImage.image = image
    }
    
    public func set(heading text: String) {
        self.headingLabel.text = text
    }
    
    public func set(subheading text: String) {
        self.subheadingLabel.text = text
    }
    
    func setupView() {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: self.nibName, bundle: bundle)
        self.contentView = nib.instantiate(withOwner: self, options: nil).first as! UIView
        
        addSubview(contentView)
        contentView.center = self.center
        contentView.autoresizingMask = []
        contentView.translatesAutoresizingMaskIntoConstraints = true
        headingLabel.text = ""
        subheadingLabel.text = ""
    }
    
    public override func didMoveToSuperview() {
        
        self.contentView.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
        
        UIView.animate(withDuration: 0.15, animations: {
            self.contentView.alpha = 1.0
            self.contentView.transform = CGAffineTransform.identity
        }) {  _ in
            self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(3.0), target: self, selector: #selector(self.removeSelf), userInfo: nil, repeats: false)
        }
    }
    
    @objc private func removeSelf() {
        UIView.animate(withDuration: 0.15, animations: {
            self.contentView.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
            self.contentView.alpha = 0.0
        }) { _ in
            self.removeFromSuperview()
        }
    }
    
    public override func layoutSubviews() {
        self.layoutIfNeeded()
        self.contentView.layer.cornerRadius = 10
        self.contentView.layer.masksToBounds = true
        self.contentView.clipsToBounds = true
    }
}
