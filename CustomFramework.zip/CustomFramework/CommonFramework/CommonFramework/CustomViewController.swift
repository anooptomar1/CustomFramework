//
//  CustomViewController.swift
//  CommonFramework
//
//  Created by Tomar, Anoop on 8/7/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

public class CustomViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var data = ["What men have called friendship is only a social arrangement, a mutual adjustment of interests, an interchange of services given and received it is, in sum, simply a business from which those involved propose to derive a steady profit for their own self-love.",
                "True human goodness, in all its purity and freedom, can come to the fore only when its recipient has no power.",
                "Who could refrain that had a heart to love and in that heart courage to make love known?",
                "I want to make movies that pierce people's hearts and touch them in some way, even if it's just for the night while they're in the cinema in that moment, I want to bring actual tears to their eyes and goosebumps to their skin.",
                "Civil union is less than marriage. Marriage is a sacred and valued institution and ought to be afforded equal protection."]
    
    lazy var tableView: UITableView = {
        let v = UITableView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.register(RandomQuotesCell.self, forCellReuseIdentifier: "cell")
        return v
    }()

    public init() {
        super.init(nibName: nil, bundle: nil)
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(tableView)
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = 500
        self.view.backgroundColor = .white
        NSLayoutConstraint.activate([
            self.tableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            self.tableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            self.tableView.topAnchor.constraint(equalTo: self.view.topAnchor),
            self.tableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
            ])
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! RandomQuotesCell
        cell.quoteLabel.text = data[indexPath.row]
        return cell
    }
}

class RandomQuotesCell: UITableViewCell {
    
    lazy var baseView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = #colorLiteral(red: 1, green: 0.7520449454, blue: 0.4455278645, alpha: 0.5)
        return v
    }()
    
    lazy var quoteLabel: UILabel = {
        let v = UILabel()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.text = "some quotes"
        v.font = UIFont(name: "Avenir Next", size: 18)
        v.numberOfLines = 0
        return v
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    private func setupView() {
        self.addSubview(baseView)
        self.baseView.addSubview(quoteLabel)
        NSLayoutConstraint.activate([
            self.baseView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 2),
            self.baseView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: 2),
            self.baseView.topAnchor.constraint(equalTo: self.topAnchor, constant: 2),
            self.baseView.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 2),
            self.quoteLabel.leadingAnchor.constraint(equalTo: self.baseView.leadingAnchor, constant: 10),
            self.quoteLabel.trailingAnchor.constraint(equalTo: self.baseView.trailingAnchor, constant: -10),
            self.quoteLabel.topAnchor.constraint(equalTo: self.baseView.topAnchor, constant: 10),
            self.quoteLabel.bottomAnchor.constraint(equalTo: self.baseView.bottomAnchor, constant: -10),
            ])
    }
}
