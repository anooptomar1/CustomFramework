//
//  QuotesModel.swift
//  CommonFramework
//
//  Created by Tomar, Anoop on 11/27/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import Foundation
public class QuotesModel {
    var quote:String
    var author: String
    var image: UIImage
    public init(quote: String, author: String, image: UIImage) {
        self.quote = quote
        self.author = author
        self.image = image
    }
}
