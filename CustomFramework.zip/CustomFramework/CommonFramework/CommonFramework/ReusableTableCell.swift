//
//  ReusableTableCell.swift
//  CommonFramework
//
//  Created by Tomar, Anoop on 11/26/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

public class ReusableTableCell: UITableViewCell {
    
    public var quoteModel: QuotesModel? {
        didSet {
            if let q = quoteModel {
                self.backgroundImg.image = q.image
                self.quotesLabel.text = q.quote
                self.byLabel.text = q.author
            }
        }
    }
    
    lazy var backgroundImg: UIImageView = {
        let v = UIImageView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.contentMode = .scaleAspectFit
        v.alpha = 0.3
        return v
    }()
    
    lazy var quotesLabel: UILabel = {
        let v = UILabel()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.text = "some text"
        v.font = v.font.withSize(24)
        v.numberOfLines = 0
        return v
    }()
    
    lazy var byLabel: UILabel = {
        let v = UILabel()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.text = "- By: Someone"
        v.font = v.font.withSize(16)
        return v
    }()
    
    private func setupView() {
        self.addSubview(backgroundImg)
        self.addSubview(quotesLabel)
        self.addSubview(byLabel)
        
        NSLayoutConstraint.activate([
            self.backgroundImg.widthAnchor.constraint(equalToConstant: 100),
            self.backgroundImg.heightAnchor.constraint(equalToConstant: 100),
            self.backgroundImg.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10),
            self.backgroundImg.topAnchor.constraint(equalTo: self.topAnchor, constant: 20),
            
            self.quotesLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20),
            self.quotesLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20),
            self.quotesLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 40),
            self.quotesLabel.bottomAnchor.constraint(equalTo: self.byLabel.topAnchor, constant: -20),
                self.byLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10),
                self.byLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10)
                
            ])
    }
    public override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    public override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
