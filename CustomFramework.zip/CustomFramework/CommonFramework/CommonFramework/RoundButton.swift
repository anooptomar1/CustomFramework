//
//  RoundButton.swift
//  CommonFramework
//
//  Created by Tomar, Anoop on 8/3/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable public class RoundButton: UIButton {
    
    @IBInspectable public var fillColor: UIColor = UIColor.blue
    @IBInspectable public var cornerRadius: CGFloat = 0
    @IBInspectable public var lineThickness: CGFloat = 0
    @IBInspectable public var linePathColor: UIColor = UIColor.white
    
    public override func draw(_ rect: CGRect) {
        layer.cornerRadius = cornerRadius
        layer.backgroundColor = fillColor.cgColor
        
        let lineT: CGFloat = lineThickness
        let lineWidth: CGFloat = min(bounds.width, bounds.height) * 0.6
        
        let linePath = UIBezierPath()
        linePath.lineWidth = lineT
        
        linePath.move(to: CGPoint(x: bounds.width/2 - lineWidth/2 + 0.5, y: bounds.height/2 + 0.5))
        linePath.addLine(to: CGPoint(x: bounds.width/2 + lineWidth/2 + 0.5, y: bounds.height/2 + 0.5))
        
        linePath.move(to: CGPoint(x: bounds.width/2 + 0.5, y: bounds.height/2 - lineWidth/2 + 0.5))
        linePath.addLine(to: CGPoint(x: bounds.width/2 + 0.5, y: bounds.height/2 + lineWidth/2 + 0.5))
        
        linePathColor.setStroke()
        linePath.stroke()
    }
    
}
